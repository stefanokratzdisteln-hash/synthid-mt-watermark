"""Reproduce the v20 statistical audit without modifying experimental inputs.

Run with the preserved experiment environment:
  TP_new_1109/experiment/.venv/Scripts/python.exe -B \
    TP_new_1109/v20_support/analysis/audit_stats.py --verify-detector

All outputs are written alongside this script. --verify-detector checks both
CUDA and CPU reconstruction of the correct-key scores; it never loads model
weights or generates translations. Inputs are joined by passage ID, not order.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import math
import platform
import re
import sys
from collections import Counter
from pathlib import Path

import numpy as np
from scipy import stats

OUT = Path(__file__).resolve().parent
PAPER = OUT.parents[1]
SEED = 20261115
RESAMPLES = 10000
METRICS = {
    "correct_key_g": ("Correct-key mean g-score", "g_off", "g_on"),
    "score_gap": ("Score gap", "gap_off", "gap_on"),
    "mattr": ("MATTR window 50", "mattr_off", "mattr_on"),
    "repeated_trigram": ("Repeated trigram ratio", "tri_off", "tri_on"),
}
INPUTS = {
    "sources": PAPER / "data/clean_60_texts.csv",
    "translations": PAPER / "experiment/translation_results.csv",
    "analysis_translations": PAPER / "decection/data/translation_results.csv",
    "metrics": PAPER / "decection/data/metrics_per_item.csv",
    "score_gaps": PAPER / "decection/data/score_gap_results.csv",
    "generation_script": PAPER / "experiment/run_experiment_synthid.py",
    "metric_script": PAPER / "decection/scripts/compute_metrics.py",
    "gap_script": PAPER / "decection/scripts/compute_score_gap.py",
    "model_generation_config": PAPER / "experiment/Qwen2.5-3B-Instruct/generation_config.json",
    "tokenizer": PAPER / "experiment/Qwen2.5-3B-Instruct/tokenizer.json",
    "tokenizer_config": PAPER / "experiment/Qwen2.5-3B-Instruct/tokenizer_config.json",
}
HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def indexed(rows, key):
    result = {r[key]: r for r in rows}
    assert len(result) == len(rows), f"Duplicate IDs in {key}"
    return result


def write_csv(name, rows):
    with (OUT / name).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def input_hashes():
    return [
        {"role": role, "path": str(path.resolve()), "size_bytes": path.stat().st_size,
         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        for role, path in INPUTS.items()
    ]


def align(a, b):
    a, b = a.split(), b.split()
    count = min(len(a), len(b))
    return " ".join(a[:count]), " ".join(b[:count]), count


def repeated_trigram(text):
    words = re.findall(r"[a-z0-9']+", text.lower())
    trigrams = [tuple(words[i:i + 3]) for i in range(len(words) - 2)]
    assert trigrams
    counts = Counter(trigrams)
    return sum(c for c in counts.values() if c > 1) / len(trigrams)


def link_and_validate():
    from lexicalrichness import LexicalRichness
    source = indexed(read_csv(INPUTS["sources"]), "编号")
    raw = indexed(read_csv(INPUTS["translations"]), "id")
    metrics = indexed(read_csv(INPUTS["metrics"]), "id")
    gaps = indexed(read_csv(INPUTS["score_gaps"]), "id")
    assert set(source) == set(raw) == set(metrics) == set(gaps)
    assert INPUTS["translations"].read_bytes() == INPUTS["analysis_translations"].read_bytes()
    linked, errors = [], {"mattr": [], "repeated_trigram": [], "correct_g_cross_file": [], "gap_arithmetic": []}
    for item_id in sorted(raw):
        r, s, m, g = raw[item_id], source[item_id], metrics[item_id], gaps[item_id]
        assert r["zh_source"] == s["段落原文"], item_id
        assert r["group"] == s["组别"], item_id
        assert r["en_watermark_off"].strip() and r["en_watermark_on"].strip(), item_id
        off, on, count = align(r["en_watermark_off"], r["en_watermark_on"])
        assert count == int(m["words_matched"])
        rec = {
            "id": item_id, "source_file": s["来源文件序号"],
            "source_paragraph_id": s["篇内段落序号"], "group": r["group"],
            "topic": r["topic"], "source_han_count": len(HAN.findall(r["zh_source"])),
            "raw_words_off": len(r["en_watermark_off"].split()),
            "raw_words_on": len(r["en_watermark_on"].split()), "words_matched": count,
            "generated_tokens_off": int(r["tokens_off"]),
            "generated_tokens_on": int(r["tokens_on"]), "seed": int(r["seed"]),
            "han_off": len(HAN.findall(r["en_watermark_off"])),
            "han_on": len(HAN.findall(r["en_watermark_on"])),
            "wrong_key_mean_off": float(g["g_off_wrong_mean"]),
            "wrong_key_mean_on": float(g["g_on_wrong_mean"]),
        }
        assert rec["source_file"]
        for key, (_, off_key, on_key) in METRICS.items():
            values = g if key == "score_gap" else m
            rec[off_key], rec[on_key] = float(values[off_key]), float(values[on_key])
            rec[key + "_diff"] = rec[on_key] - rec[off_key]
        for tag, text in [("off", off), ("on", on)]:
            lexical = LexicalRichness(text.lower())
            rec["mattr_words_" + tag] = lexical.words
            errors["mattr"].append(abs(lexical.mattr(window_size=50) - rec["mattr_" + tag]))
            errors["repeated_trigram"].append(abs(repeated_trigram(text) - rec["tri_" + tag]))
            errors["correct_g_cross_file"].append(abs(rec["g_" + tag] - float(g["g_" + tag + "_correct"])))
            errors["gap_arithmetic"].append(abs(rec["gap_" + tag] - (rec["g_" + tag] - rec["wrong_key_mean_" + tag])))
        assert all(math.isfinite(rec[k]) for _, a, b in METRICS.values() for k in (a, b))
        linked.append(rec)
    maxima = {key: max(values) for key, values in errors.items()}
    assert all(error < 1e-12 for error in maxima.values()), maxima
    return linked, raw, maxima


def summarize_subset(rows, subset_name):
    # Sorted file names define cluster order. Reset the same RNG seed once per
    # subset. All four outcomes use the identical sampled file-index matrix.
    file_ids = np.array([row["source_file"] for row in rows])
    clusters = np.unique(file_ids)
    groups = [np.flatnonzero(file_ids == name) for name in clusters]
    sizes = np.array([len(group) for group in groups])
    draws = np.random.default_rng(SEED).integers(0, len(groups), size=(RESAMPLES, len(groups)))
    denominator = sizes[draws].sum(axis=1)
    result = {
        "name": subset_name, "n_pairs": len(rows), "n_source_files": len(clusters),
        "included_ids": [r["id"] for r in rows],
        "cluster_sizes": {str(name): int(size) for name, size in zip(clusters, sizes)},
        "bootstrap_seed": SEED, "bootstrap_resamples": RESAMPLES, "outcomes": {},
    }
    for key, (label, off_key, on_key) in METRICS.items():
        off = np.array([row[off_key] for row in rows])
        on = np.array([row[on_key] for row in rows])
        diff = on - off
        sums = np.array([diff[group].sum() for group in groups])
        bootstrap_means = sums[draws].sum(axis=1) / denominator
        test = stats.ttest_rel(on, off)
        t_ci = stats.t.interval(.95, len(rows) - 1, loc=diff.mean(), scale=stats.sem(diff))
        result["outcomes"][key] = {
            "label": label, "off_mean": float(off.mean()), "off_sd": float(off.std(ddof=1)),
            "on_mean": float(on.mean()), "on_sd": float(on.std(ddof=1)),
            "off_range": [float(off.min()), float(off.max())],
            "on_range": [float(on.min()), float(on.max())],
            "mean_difference": float(diff.mean()), "sd_difference": float(diff.std(ddof=1)),
            "cohens_dz": float(diff.mean() / diff.std(ddof=1)),
            "original_paired_t": {"t": float(test.statistic), "df": len(rows) - 1,
                                  "p_two_sided": float(test.pvalue), "ci95": list(map(float, t_ci))},
            "source_file_cluster_bootstrap_ci95": list(map(float, np.quantile(bootstrap_means, [.025, .975], method="linear"))),
            "increased": int((diff > 0).sum()), "decreased": int((diff < 0).sum()),
            "ties": int((diff == 0).sum()),
            "in_sample_ranges_separate": bool(off.max() < on.min() or on.max() < off.min()),
            "wilcoxon_two_sided_p": float(stats.wilcoxon(on, off).pvalue),
            "shapiro_difference_p": float(stats.shapiro(diff).pvalue),
        }
    return result


def detector_audit(rows, raw):
    import torch
    from transformers import AutoTokenizer, SynthIDTextWatermarkLogitsProcessor
    tokenizer = AutoTokenizer.from_pretrained(str(PAPER / "experiment/Qwen2.5-3B-Instruct"), local_files_only=True)
    keys = [654, 400, 836, 123, 340, 443, 597, 160, 57, 29, 590, 639, 13, 715, 468, 990, 966, 226, 324, 585]
    devices = ["cpu"] + (["cuda"] if torch.cuda.is_available() else [])
    processors = {dev: SynthIDTextWatermarkLogitsProcessor(
        ngram_len=5, keys=keys, sampling_table_size=2**16, sampling_table_seed=0,
        context_history_size=1024, device=torch.device(dev)) for dev in devices}
    token_differences, actual_scored_differences, texts = [], [], []
    for row in rows:
        r = raw[row["id"]]
        off, on, _ = align(r["en_watermark_off"], r["en_watermark_on"])
        for tag, text in [("off", off), ("on", on)]:
            raw_count = len(tokenizer(r["en_watermark_" + tag], add_special_tokens=False)["input_ids"])
            ids = tokenizer(text, add_special_tokens=False, return_tensors="pt")["input_ids"]
            token_differences.append(int(r["tokens_" + tag]) - raw_count)
            actual_scored_differences.append(int(r["tokens_" + tag]) - ids.shape[1])
            texts.append((row, tag, ids))
    result = {"cuda_available": torch.cuda.is_available(), "devices": {},
              "generation_token_ids_saved": False,
              "raw_saved_minus_reencoded_token_count": {
                  "mean": float(np.mean(token_differences)), "range": [min(token_differences), max(token_differences)],
                  "frequency": dict(Counter(token_differences))},
              "saved_minus_actual_scored_token_count": {
                  "mean": float(np.mean(actual_scored_differences)),
                  "range": [min(actual_scored_differences), max(actual_scored_differences)]}}
    for dev, processor in processors.items():
        errors, valid = [], []
        for row, tag, cpu_ids in texts:
            ids = cpu_ids.to(dev)
            g = processor.compute_g_values(ids)
            mask = processor.compute_context_repetition_mask(ids)
            mask *= processor.compute_eos_token_mask(ids, eos_token_id=tokenizer.eos_token_id)[:, 4:]
            assert int(mask.sum()) > 0
            score = float((g.float() * mask.unsqueeze(-1)).sum() / (mask.sum() * g.shape[-1]))
            errors.append(abs(score - row["g_" + tag]))
            valid.append(int(mask.sum()))
        table_bytes = processor.sampling_table.cpu().numpy().tobytes()
        result["devices"][dev] = {"n_texts": len(texts), "max_abs_error_vs_cached": max(errors),
            "mean_abs_error_vs_cached": float(np.mean(errors)), "valid_positions_range": [min(valid), max(valid)],
            "sampling_table_sha256": hashlib.sha256(table_bytes).hexdigest(),
            "sampling_table_dtype": str(processor.sampling_table.dtype)}
        print(f"Detector validation {dev}: max cached-score difference {max(errors):.9g}", flush=True)
    if "cuda" in processors:
        result["gpu_name"] = torch.cuda.get_device_name(0)
        result["cpu_cuda_sampling_tables_equal"] = torch.equal(processors["cpu"].sampling_table, processors["cuda"].sampling_table.cpu())
        assert result["devices"]["cuda"]["max_abs_error_vs_cached"] < 1e-7
    result["interpretation"] = (
        "Cached scores are CUDA-table dependent. Reinitializing the same table seed on CPU does not reproduce them. "
        "Raw re-encoded token-count closeness does not establish original token-ID equality, and it does not describe "
        "the truncated, whitespace-normalized scoring text. No translation generation was performed.")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-detector", action="store_true")
    args = parser.parse_args()
    hashes_before = input_hashes()
    rows, raw, validation = link_and_validate()
    subsets = {
        "full60": rows,
        "main50": [row for row in rows if row["group"] == "正式"],
        "exclude_han54": [row for row in rows if row["han_off"] + row["han_on"] == 0],
    }
    assert [len(subset) for subset in subsets.values()] == [60, 50, 54]
    report = {
        "schema": "eng2001-v20-statistical-audit/1", "analysis_date": "2026-11-15",
        "runtime": {"executable": sys.executable, "python": sys.version, "platform": platform.platform(),
                    "versions": {name: importlib.metadata.version(name) for name in
                                 ["numpy", "scipy", "torch", "transformers", "lexicalrichness"]}},
        "inputs": hashes_before,
        "linked_items": rows,
        "definitions": {
            "difference": "watermark enabled minus watermark disabled",
            "alignment": "Split raw text by whitespace; keep min(pair word counts) leading words; join with a single space. ALL FOUR outcomes use this aligned text.",
            "mattr": "LexicalRichness(aligned_text.lower()).mattr(window_size=50), version recorded below. Defaults remove digits and hyphen/en-dash/em-dash characters, replace ASCII punctuation with spaces, and split on whitespace. Hyphen removal joins components. Non-ASCII/Han text is not explicitly removed. Average distinct-word proportion across every overlapping 50-word window.",
            "repeated_trigram_ratio": "Extract lowercase tokens with regex [a-z0-9']+; create consecutive 3-token sequences. Numerator is sum of occurrence counts for trigram types occurring more than once, including first occurrences; denominator is all trigram occurrences. Not one minus unique/total.",
            "g_score": "Mean of binary g-values over valid (position, depth) cells using 20 keys, 5-gram context, repeated-context and EOS masks. Re-tokenize aligned text without special tokens. Initial four positions are excluded. A continuous score, not a calibrated probability.",
            "score_gap": "Correct-key g-score minus mean score from five wrong key sets. Incorrect-key seeds 101,202,303,404,505 generate 20 torch.randint(0,10000) values each.",
            "bootstrap": "For each subset independently, sort unique source-file IDs; draw C source-file indices with replacement for each of 10000 replicates, where C is that subset's source-file count. Include every passage from each selected file, including repeated selection. Compute sum of all sampled paired differences divided by sampled passage count (passage-weighted mean). Reset numpy.default_rng(20261115) once per subset; use identical draws for all four outcomes. Percentile endpoints use numpy.quantile([.025,.975],method='linear').",
            "inference": "Source-file cluster bootstrap intervals are new sensitivity analyses, not preregistered. Original paired t tests assume passage independence and are retained for comparison. Tests and intervals are unadjusted for multiple outcomes. Non-significance is not equivalence. Subsets are sensitivity analyses, not holdout test sets.",
        },
        "validation": {"max_abs_recalculation_error": validation,
            "raw_source_text_matches": True, "translation_copies_byte_identical": True,
            "missing_paragraph_positions": sum(not row["source_paragraph_id"] for row in rows),
            "han_excluded_ids": [row["id"] for row in rows if row["han_off"] + row["han_on"]],
            "wrong_key_means": {tag: float(np.mean([row["wrong_key_mean_" + tag] for row in rows])) for tag in ["off", "on"]},
            "matched_word_count": {"mean": float(np.mean([row["words_matched"] for row in rows])),
                                   "range": [min(row["words_matched"] for row in rows), max(row["words_matched"] for row in rows)]}},
        "subsets": {name: summarize_subset(subset, name) for name, subset in subsets.items()},
    }
    print("Statistics and lexical definitions validated for full60, main50 and exclude_han54.", flush=True)
    if args.verify_detector:
        report["detector_validation"] = detector_audit(rows, raw)
    else:
        report["detector_validation"] = {"performed_in_this_run": False}
    hashes_after = input_hashes()
    assert hashes_before == hashes_after, "An input changed during the audit"
    report["validation"]["input_hashes_unchanged_after_analysis"] = True
    report["audit_script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    write_csv("input_hashes.csv", hashes_before)
    write_csv("linked_items.csv", rows)
    flat = []
    for name, subset in report["subsets"].items():
        for key, outcome in subset["outcomes"].items():
            t = outcome["original_paired_t"]
            lo, hi = outcome["source_file_cluster_bootstrap_ci95"]
            flat.append({"subset": name, "outcome": key, "n_pairs": subset["n_pairs"],
                "n_source_files": subset["n_source_files"], "off_mean": outcome["off_mean"],
                "off_sd": outcome["off_sd"], "on_mean": outcome["on_mean"], "on_sd": outcome["on_sd"],
                "mean_difference": outcome["mean_difference"], "cluster_ci95_low": lo, "cluster_ci95_high": hi,
                "paired_t": t["t"], "paired_t_df": t["df"], "paired_t_p_two_sided": t["p_two_sided"],
                "original_t_ci95_low": t["ci95"][0], "original_t_ci95_high": t["ci95"][1],
                "cohens_dz": outcome["cohens_dz"], "increased": outcome["increased"],
                "decreased": outcome["decreased"], "ties": outcome["ties"]})
    write_csv("summary_statistics.csv", flat)
    (OUT / "results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Wrote reproducible audit outputs to {OUT}", flush=True)


if __name__ == "__main__":
    main()
