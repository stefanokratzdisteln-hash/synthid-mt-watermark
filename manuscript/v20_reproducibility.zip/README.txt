ENG2001 v20 reproducibility records

This package accompanies v20_f_compact.docx. It retains the exact prompts,
configuration, input texts, paired translations, per-item scores and analysis
records that are summarized in the compact appendices. No new translations
were generated for the appendix revision.

VERIFY THE NUMBERS

With Python, NumPy and SciPy available, run from any working directory:

    python -B path/to/verify_cached_results.py

The command is read-only. It verifies the package file hashes, joins the source
and outcome files by passage ID, and recomputes the full 60-pair sample, the
50-passage main subset, and the 54-pair subset without Chinese remnants.
It checks paired means/differences, two-sided paired t tests and their original
intervals, and the source-file cluster bootstrap intervals against results.json.
Each subset resets NumPy default_rng(20261115), samples its source files with
replacement 10,000 times, retains all passages within each sampled file, and
uses a passage-weighted mean. The four outcomes share the same draws.
Expected source-file counts are 49, 49 and 44, respectively.

CONTENTS

experiment_config.json          Exact messages, template options, parameters,
                               full correct/wrong key values, definitions and
                               detector validation records.
model_config/                  Model, generation and tokenizer configuration;
                               the tokenizer configuration includes the exact
                               chat template.
data/                          Original source passages, translations, metrics
                               and score gaps, copied without changes.
analysis/                      Linked rows, full statistics, summary table and
                               source-input hashes. Host-specific paths in
                               results.json/input_hashes.csv were converted
                               to package-relative paths; numeric data are
                               unchanged. The absent tokenizer file is marked.
provenance/                    Exact copies of original generation, metric,
                               score-gap and audit scripts.
manifest.json                  SHA-256 hashes of package files and relative
                               project source locations for copied files.
requirements-recorded.txt       Recorded analysis versions, not an installation
                               instruction or guarantee of cross-platform use.

GENERATION AND DETECTOR REPLAY

The portable verifier reproduces statistics from archived values. It does not
re-tokenize texts or recompute watermark scores. The provenance scripts retain
their original project-relative layout and are reference copies, not turnkey
commands in this package. To replay generation or detection, restore the
original project layout or adjust only the copies' input/model/output paths.
Supply the Qwen2.5-3B-Instruct weights and full tokenizer files separately;
neither is bundled. Exact messages and chat-template options are recorded in
experiment_config.json. Keep all sampling and watermark settings unchanged.

The stored detector scores use a CUDA-generated sampling table. With the
recorded environment, CUDA rescoring matched all 120 correct-key values
exactly. CPU initialization at the same seed generates a different table
(maximum observed score discrepancy 0.06696749), so CPU initialization is not
an interchangeable replay. No frozen model revision or original generated
token IDs were archived; therefore exact generation-sequence replay is not
established. The configured model and tokenizer metadata are preserved here
without claiming a missing revision or missing token IDs can be recovered.

INTERPRETATION

Cluster and subset analyses were added after the original analysis, not
preregistered. Intervals/tests are unadjusted for multiple outcomes. Subsets
are sensitivity checks, not independent test sets. Non-significance does not
establish equivalence or unchanged translation quality. There is no calibrated
classification threshold, human-written control or validated false-positive
rate. The original scripts and paired outputs are also available at:
https://github.com/stefanokratzdisteln-hash/synthid-mt-watermark

LCMC passages retain the corpus's original terms; this package does not
relicense them. This local package has not been published or uploaded.
