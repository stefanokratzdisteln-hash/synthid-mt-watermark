"""Verify all paper statistics from archived per-item values, without GPU access.

Usage: python -B verify_cached_results.py
Requires NumPy and SciPy. No model, network, generation, or detector run.
The default command is read-only and prints its verification report.
"""
from pathlib import Path
import csv, hashlib, json, re, sys
import numpy as np
from scipy import stats

BASE=Path(__file__).resolve().parent
SEED=20261115
RESAMPLES=10000
METRICS={'correct_key_g':('g_off','g_on'),'score_gap':('gap_off','gap_on'),
         'mattr':('mattr_off','mattr_on'),'repeated_trigram':('tri_off','tri_on')}
def csv_rows(path):
    with (BASE/path).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def indexed(rows,key):
    out={r[key]:r for r in rows}
    assert len(out)==len(rows),f'Duplicate {key}'
    return out
def main():
    manifest=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
    for record in manifest['files']:
        p=BASE/record['path']
        assert p.is_file(),str(p)
        assert hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'],record['path']
    sources=indexed(csv_rows('data/clean_60_texts.csv'),'编号')
    raw=indexed(csv_rows('data/translation_results.csv'),'id')
    metrics=indexed(csv_rows('data/metrics_per_item.csv'),'id')
    gaps=indexed(csv_rows('data/score_gap_results.csv'),'id')
    links=indexed(csv_rows('analysis/linked_items.csv'),'id')
    assert set(sources)==set(raw)==set(metrics)==set(gaps)==set(links)
    assert len(raw)==60
    expected=json.loads((BASE/'analysis/results.json').read_text(encoding='utf-8'))
    han=re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff]')
    rows=[]
    for item_id in sorted(raw):
        source,text,m,g,link=sources[item_id],raw[item_id],metrics[item_id],gaps[item_id],links[item_id]
        assert source['段落原文']==text['zh_source']
        assert source['来源文件序号']==link['source_file']
        assert source['组别']==text['group']==link['group']
        row={'id':item_id,'source_file':source['来源文件序号'],'group':text['group'],
             'han':len(han.findall(text['en_watermark_off']))+len(han.findall(text['en_watermark_on']))}
        assert row['han']==int(link['han_off'])+int(link['han_on'])
        for name,(off,on) in METRICS.items():
            source_metric=g if name=='score_gap' else m
            row[off],row[on]=float(source_metric[off]),float(source_metric[on])
            assert row[off]==float(link[off]) and row[on]==float(link[on])
        for side in ['off','on']:
            assert row['g_'+side]==float(g['g_'+side+'_correct'])
            assert abs(row['gap_'+side]-(row['g_'+side]-float(g['g_'+side+'_wrong_mean'])))<1e-12
        rows.append(row)
    subsets={'full60':rows,'main50':[r for r in rows if r['group']=='正式'],
             'exclude_han54':[r for r in rows if r['han']==0]}
    comparisons=[]
    summary={}
    for name,items in subsets.items():
        ref=expected['subsets'][name]
        file_ids=np.array([r['source_file'] for r in items])
        unique=np.unique(file_ids)
        assert len(items)==ref['n_pairs'] and len(unique)==ref['n_source_files']
        assert [r['id'] for r in items]==ref['included_ids']
        clusters=[np.flatnonzero(file_ids==x) for x in unique]
        sizes=np.array([len(c) for c in clusters])
        draws=np.random.default_rng(SEED).integers(0,len(clusters),size=(RESAMPLES,len(clusters)))
        denom=sizes[draws].sum(axis=1)
        summary[name]={'pairs':len(items),'source_files':len(unique),'outcomes':{}}
        for metric,(off_key,on_key) in METRICS.items():
            off=np.array([r[off_key] for r in items]);on=np.array([r[on_key] for r in items]);d=on-off
            sums=np.array([d[c].sum() for c in clusters])
            boot=sums[draws].sum(axis=1)/denom
            interval=np.quantile(boot,[.025,.975],method='linear')
            test=stats.ttest_rel(on,off)
            t_ci=stats.t.interval(.95,len(items)-1,loc=d.mean(),scale=stats.sem(d))
            got={'off_mean':float(off.mean()),'on_mean':float(on.mean()),'mean_difference':float(d.mean()),
                 'cluster_ci95':list(map(float,interval)),'t':float(test.statistic),
                 'p_two_sided':float(test.pvalue),'original_t_ci95':list(map(float,t_ci))}
            target=ref['outcomes'][metric]
            actual=np.array([got['off_mean'],got['on_mean'],got['mean_difference'],*interval,test.statistic,test.pvalue,*t_ci])
            want=np.array([target['off_mean'],target['on_mean'],target['mean_difference'],
                           *target['source_file_cluster_bootstrap_ci95'],target['original_paired_t']['t'],
                           target['original_paired_t']['p_two_sided'],*target['original_paired_t']['ci95']])
            np.testing.assert_allclose(actual,want,rtol=1e-10,atol=1e-13,err_msg=f'{name}/{metric}')
            comparisons.extend(abs(actual-want))
            summary[name]['outcomes'][metric]=got
    print(json.dumps({'status':'pass','verified_manifest_files':len(manifest['files']),
        'source_rows':60,'all_id_joins_match':True,'bootstrap_resamples':RESAMPLES,'bootstrap_seed':SEED,
        'max_absolute_numeric_difference':float(max(comparisons)),
        'runtime':{'python':sys.version.split()[0],'numpy':np.__version__,'scipy':__import__('scipy').__version__},
        'scope':'Cached per-item statistics and source linkage only; no translation or detector execution.',
        'subsets':summary},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
